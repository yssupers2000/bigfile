\# Linux Training

\## CLI Commands

\### 디렉토리

\### 도움말

\### 파일 생성, 출력, 병합

\### 파일 카운트

